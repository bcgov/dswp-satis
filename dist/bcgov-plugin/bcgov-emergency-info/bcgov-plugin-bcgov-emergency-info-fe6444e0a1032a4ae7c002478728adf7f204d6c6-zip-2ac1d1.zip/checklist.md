Created at 2025-03-05 3:23 pm

* [yes] Updated version in composer.json
* [yes] Updated version in style.css or plugin file
* [yes] Updated CHANGELOG.md to include jira ticket
* [no] Updated README.md for new functionality
* [no] Built assets for production (npm run build:production)
* [N/A] Updated the documentation (N/A, Updated, or a ticket ID)
* [✓] Verified coding standards (phpcs)
* [✓] Run PHP tests
* [✓] Lint javascript
* [✓] Lint CSS
* [✓] Javascript Tests