<?php
/**
 * Title: About Us (Page)
 * Slug: design-system-wordpress-child-theme-emergency-info/page-about-us
 * Categories: page
 *
 * @package Design-System-WordPress-Theme
 */
?>

<!-- wp:group {"style":{"spacing":{"margin":{"top":"var:preset|spacing|30","bottom":"var:preset|spacing|30"}}},"layout":{"type":"default"}} -->
<div class="wp-block-group" style="margin-top:var(--wp--preset--spacing--30);margin-bottom:var(--wp--preset--spacing--30)"><!-- wp:group {"layout":{"type":"default"}} -->
    <div class="wp-block-group"><!-- wp:group {"className":"alignwide","style":{"spacing":{"padding":{"top":"var:preset|spacing|20","right":"var:preset|spacing|20","bottom":"var:preset|spacing|20","left":"var:preset|spacing|20"}}},"layout":{"type":"constrained"}} -->
        <div class="wp-block-group alignwide" style="padding-top:var(--wp--preset--spacing--20);padding-right:var(--wp--preset--spacing--20);padding-bottom:var(--wp--preset--spacing--20);padding-left:var(--wp--preset--spacing--20)"><!-- wp:group {"layout":{"type":"default"}} -->
            <div class="wp-block-group"><!-- wp:group {"style":{"spacing":{"blockGap":"var:preset|spacing|30"}},"layout":{"type":"default"}} -->
                <div class="wp-block-group">

                    <!-- wp:paragraph -->
                    <p>EmergencyInfoBC provides emergency information for people in B.C. online at <a href="https://www.emergencyinfobc.ca/" title="">www.EmergencyInfoBC.ca</a> and on social media at <a href="https://x.com/emergencyinfobc" target="_blank" rel="noopener" title="">@EmergencyInfoBC on X (Twitter)</a> and on <a href="https://www.facebook.com/EmergencyInfoBC" target="_blank" rel="noopener" title="">Facebook</a>.</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:paragraph -->
                    <p>The EmergencyInfoBC website helps people find current and official information about:</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:list -->
                    <ul class="wp-block-list"><!-- wp:list-item -->
                        <li>Emergencies happening in British Columbia</li>
                        <!-- /wp:list-item -->

                        <!-- wp:list-item -->
                        <li>How to stay safe during an emergency</li>
                        <!-- /wp:list-item -->

                        <!-- wp:list-item -->
                        <li>How to recover after an emergency</li>
                        <!-- /wp:list-item -->
                    </ul>
                    <!-- /wp:list -->

                    <!-- wp:paragraph -->
                    <p>This website is updated 24 hours a day, 7 days a week.</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:paragraph -->
                    <p>EmergencyInfoBC is directed by the <a href="https://www2.gov.bc.ca/gov/content?id=927BDE69092E469BB4C4DC3AF4FD109E" title="">Ministry of Emergency Management and Climate Readiness</a>. This ministry is the province’s lead coordinating agency for all disaster management activities, including emergency preparedness, response, recovery and risk mitigation.</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:paragraph -->
                    <p><a href="https://civicinfo.bc.ca/directories" title="">Contact your local authority</a>&nbsp;for more detailed and local emergency information. Your local authority may include your regional district, municipality or First Nation.</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:heading {"className":"is-style-alphagov-heading is-style-heading-callout"} -->
                    <h2 class="wp-block-heading is-style-alphagov-heading is-style-heading-callout">Social media</h2>
                    <!-- /wp:heading -->

                    <!-- wp:paragraph -->
                    <p><a href="https://twitter.com/EmergencyInfoBC" title="">Follow @EmergencyInfoBC on X</a> (Twitter) or <a href="https://www.facebook.com/EmergencyInfoBC" title="">Facebook</a> for updates.</p>
                    <!-- /wp:paragraph -->

                    <!-- wp:heading {"className":"is-style-alphagov-heading is-style-heading-callout"} -->
                    <h2 class="wp-block-heading is-style-alphagov-heading is-style-heading-callout">Media contacts</h2>
                    <!-- /wp:heading -->

                    <!-- wp:paragraph -->
                    <p>For media enquiries related to the Ministry of Emergency Management and Climate Readiness, call <a href="tel:+12508806430" target="_blank" rel="noreferrer noopener">250-880-6430</a>. </p>
                    <!-- /wp:paragraph -->

                    <!-- wp:paragraph -->
                    <p>For media contact information organized by Ministry, visit the <a href="https://news.gov.bc.ca/contacts" title="">Government Communications and Public Engagement Contact List for Media</a>. </p>
                    <!-- /wp:paragraph -->

                    <!-- wp:list -->
                    <ul class="wp-block-list"><!-- wp:list-item -->
                        <li>For media enquiries related to flood watches, warnings and advisories, contact the Ministry of Water, Land and Resource Stewardship.</li>
                        <!-- /wp:list-item -->

                        <!-- wp:list-item -->
                        <li>For media enquiries related to infrastructure, highways and road work, contact the Ministry of Transportation and Infrastructure.</li>
                        <!-- /wp:list-item -->

                        <!-- wp:list-item -->
                        <li>For media enquiries related to wildfires, visit the <a href="https://www2.gov.bc.ca/gov/content?id=562800242A7446518BD919F0C3A70FE2" title="">BC Wildfire Service Media Information Contact List</a>.</li>
                        <!-- /wp:list-item -->
                    </ul>
                    <!-- /wp:list -->

                    <!-- wp:paragraph -->
                    <p>For media enquires related to local States of Emergency and Evacuation Orders or Alerts, contact the <a href="https://www.civicinfo.bc.ca/directories" target="_blank" rel="noreferrer noopener">local authority</a>.</p>
                    <!-- /wp:paragraph -->
                </div>
                <!-- /wp:group -->
            </div>
            <!-- /wp:group -->
        </div>
        <!-- /wp:group -->
    </div>
    <!-- /wp:group -->
</div>
<!-- /wp:group -->