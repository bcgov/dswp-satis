Created at 2022-09-14 8:13 pm

* [yes] Updated version in composer.json
* [yes] Updated version in style.css or plugin file
* [yes] Updated CHANGELOG.md to include jira ticket
* [yes] Updated README.md for new functionality
* [yes] Built assets for production (npm run build:production)
* [✓] Verified coding standards (phpcs)
* [✓] Run PHP tests
* [✓] Lint javascript
* [✓] Lint CSS
* [✓] Javascript Tests
