<?php
/**
 * Design System Plugin dependency: auto-activate on theme switch, allow admins to disable, show notice when inactive.
 *
 * @package Design_System_WordPress_Theme
 */

use Bcgov\Theme\DesignSystem\LegacyPatterns;

/**
 * Plugin path (relative to wp-content/plugins) required by this theme.
 *
 * @return string Plugin basename path.
 */
function design_system_wordpress_theme_required_plugin() {
    return 'design-system-wordpress-plugin/design-system-wordpress-plugin.php';
}

add_action( 'after_switch_theme', 'design_system_theme_activate_plugin_on_switch', 10, 2 );
add_action( 'after_setup_theme', 'design_system_theme_register_plugin_required_notices', 5 );

/**
 * Composer autoload.
 */
$autoloader_path = __DIR__ . '/vendor/autoload.php';
if ( file_exists( $autoloader_path ) ) {
    require_once $autoloader_path;
}

/**
 * Legacy patterns.
 */
if ( class_exists( 'Bcgov\\Theme\\DesignSystem\\LegacyPatterns' ) ) {
    $legacy_patterns = new LegacyPatterns();
    $legacy_patterns->init();
}

/**
 * Fallback: allow legacy archived block patterns until dependent child themes opt in explicitly.
 *
 * Priority 100 runs late so child themes can override with a higher priority (e.g. 110).
 *
 * Remove this filter once the firb, hporoo, and ticorp child themes have added their own
 * `dswp_legacy_pattern_allow` handling.
 */
add_filter( 'dswp_legacy_pattern_allow', '__return_true', 100 );

/**
 * Auto-activate plugin when this theme is switched to; admins can disable it later.
 */
function design_system_theme_activate_plugin_on_switch() {
    $new_theme = wp_get_theme( get_stylesheet() );
    if ( 'design-system-wordpress-theme' !== $new_theme->get_template() ) {
        return;
    }
    $plugin = design_system_wordpress_theme_required_plugin();
    $path   = WP_PLUGIN_DIR . '/' . $plugin;
    if ( ! file_exists( $path ) ) {
        return;
    }
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    if ( ! is_plugin_active( $plugin ) ) {
        activate_plugin( $plugin, '', false, true );
    }
}

/** Register admin notice when plugin is inactive. */
function design_system_theme_register_plugin_required_notices() {
    require_once ABSPATH . 'wp-admin/includes/plugin.php';
    if ( is_plugin_active( design_system_wordpress_theme_required_plugin() ) ) {
        return;
    }
    add_action( 'admin_notices', 'design_system_theme_plugin_required_notice' );
}

/** Outputs the "plugin required" notice in the admin. */
function design_system_theme_plugin_required_notice() {
    $msg = __( 'This theme will not work correctly without the Design System Plugin. Please enable it.', 'design-system-wordpress-theme' );
    echo '<div class="notice notice-warning is-dismissible"><p><strong>' . esc_html__( 'Design System Theme', 'design-system-wordpress-theme' ) . ':</strong> ' . esc_html( $msg );
    if ( current_user_can( 'activate_plugins' ) ) {
        echo ' <a href="' . esc_url( admin_url( 'plugins.php' ) ) . '">' . esc_html__( 'Go to Plugins', 'design-system-wordpress-theme' ) . '</a>';
    }
    echo '</p></div>';
}

/**
 * Enqueue the design system CSS stylesheet.
 *
 * Uses the shared `design_system_get_asset_data()` helper to resolve the stylesheet
 * version, enabling consistent cache-busting behavior with `design_system_enqueue_global_js_scripts()`.
 *
 * @since 1.3.0
 *
 * @return void
 */
function design_system_public_enqueue_global_styles() {
    // design_system_get_asset_data() reads build metadata; falls back to filemtime() if missing.
    $asset = design_system_get_asset_data( get_template_directory() . '/dist/index.asset.php', get_template_directory() . '/dist/index.css' );
    wp_enqueue_style( 'design-system-styles', get_template_directory_uri() . '/dist/index.css', array(), $asset['version'] );
}

add_action( 'enqueue_block_assets', 'design_system_public_enqueue_global_styles' );
add_action( 'admin_enqueue_scripts', 'design_system_public_enqueue_global_styles' );


/**
 * Register and enqueue the theme's compiled JavaScript bundle.
 *
 * Orchestrates asset metadata resolution and WordPress script registration/enqueueing.
 * Delegates asset resolution to `design_system_get_asset_data()` for separation of concerns
 * and testability.
 *
 * @since 1.3.0
 *
 * @return void
 */
function design_system_enqueue_global_js_scripts() {
    // design_system_get_asset_data() reads build metadata; falls back to filemtime() if missing.
    $asset = design_system_get_asset_data( get_template_directory() . '/dist/index.asset.php', get_template_directory() . '/dist/index.js' );

    // Enqueue the compiled script directly. WordPress will register the handle and avoid duplicate enqueues.
    wp_enqueue_script(
        'design-system-scripts',
        get_template_directory_uri() . '/dist/index.js',
        $asset['dependencies'],
        $asset['version'],
        true
    );
}

add_action( 'enqueue_block_editor_assets', 'design_system_enqueue_global_js_scripts' );
add_action( 'wp_enqueue_scripts', 'design_system_enqueue_global_js_scripts' );

/**
 * Returns the current year for the [current_year] shortcode.
 *
 * @return string Current year in the site timezone.
 */
function design_system_current_year_shortcode() {
    return esc_html( wp_date( 'Y' ) );
}

/**
 * Registers shortcodes used by this theme.
 */
function design_system_register_shortcodes() {
    add_shortcode( 'current_year', 'design_system_current_year_shortcode' );
}

add_action( 'init', 'design_system_register_shortcodes' );

/**
 * Retrieve asset metadata (dependencies and version) for built assets.
 *
 * Resolves script dependencies and version from the asset metadata file
 * (`dist/index.asset.php`) generated by the build tool. If the metadata file
 * is missing, falls back to `filemtime()` for cache-busting the fallback file.
 *
 * @param string $asset_file     Path to the asset metadata file.
 * @param string $fallback_file  Path to the script/stylesheet file for fallback versioning.
 * @return array Associative array with 'dependencies' and 'version' keys.
 */
function design_system_get_asset_data( $asset_file, $fallback_file ) {
    $asset_data = file_exists( $asset_file ) ? include $asset_file : array();

    return array(
        'dependencies' => isset( $asset_data['dependencies'] ) && is_array( $asset_data['dependencies'] ) ? $asset_data['dependencies'] : array(),
        'version'      => isset( $asset_data['version'] ) ? $asset_data['version'] : filemtime( $fallback_file ),
    );
}

/**
 * Includes all block style variation PHP files from blocks/core directory recursively.
 *
 * @param string $dir_path The path of the directory to include files from.
 */
function design_system_include_block_style_variations( $dir_path ) {
    // Define the block style variation files.
    $block_style_variation_files = [ 'navigation', 'heading' ];

    // Include specified block style variation files.
    foreach ( glob( $dir_path . '/*.php' ) as $file ) {
        $base_name = basename( $file, '.php' );
        if ( in_array( $base_name, $block_style_variation_files, true ) && ! class_exists( $base_name ) ) {
            require_once $file;
        }
    }

    // Recursively include from subdirectories.
    foreach ( glob( $dir_path . '/*', GLOB_ONLYDIR ) as $dir ) {
        design_system_include_block_style_variations( $dir );
    }
}

// Set the directory path and include block style variations.
$dir_path = get_template_directory() . '/blocks/core/style-variations';
design_system_include_block_style_variations( $dir_path );

/**
 * Registers the post title block styles (e.g. Underline).
 *
 * @since 1.3.0
 */
function design_system_register_post_title_block_styles() {
    $block_name       = 'core/post-title';
    $style_properties = array(
        'name'         => 'underline-title',
        'label'        => __( 'Underline' ),
        'isDefault'    => false,
        'style_handle' => 'design-system-styles',
    );
    register_block_style( $block_name, $style_properties );
}
add_action( 'init', 'design_system_register_post_title_block_styles' );

/**
 * Restrict access to the locking UI to Administrators.
 *
 * @param array $settings Default editor settings.
 */
function design_system_restrict_locking_unlocking_blocks( $settings ) {
    $settings['canLockBlocks'] = current_user_can( 'activate_plugins' );
    return $settings;
}
add_filter( 'block_editor_settings_all', 'design_system_restrict_locking_unlocking_blocks', 10, 2 );


/**
 * Disables the default patterns from WordPress.
 */
function design_system_disable_default_block_patterns() {
    remove_theme_support( 'core-block-patterns' );
}
add_action( 'init', 'design_system_disable_default_block_patterns' );


/**
 * Combines any child theme's color palette with the Design System Theme Color palette.
 *
 * @param object $theme_json The theme.json schema.
 */
function design_system_combine_parent_child_theme_json( $theme_json ) {
    $theme_json_data = $theme_json->get_data();

    // If the theme_json_data is from the design system theme, this is not a child theme so exit without change.
    if ( ! is_child_theme() ) {
        return $theme_json;
    }
    // Get the parent theme.
    $theme = wp_get_theme( 'design-system-wordpress-theme' );

    // Get the path to the theme.json file using the theme's stylesheet.
    $theme_json_path = $theme->get_theme_root() . '/' . $theme->get_stylesheet() . '/theme.json';

    // Initialize parent palette.
    $parent_palette = array();

    // Check if the theme.json file exists and read it.

    if ( file_exists( $theme_json_path ) ) {
        $parent_theme_json_content = implode( '', file( $theme_json_path, FILE_IGNORE_NEW_LINES | FILE_SKIP_EMPTY_LINES ) );
        $parent_theme_json_data    = json_decode( $parent_theme_json_content, true );

        // Check if the parent theme has a color palette.
        if ( isset( $parent_theme_json_data['settings']['color']['palette'] ) && is_array( $parent_theme_json_data['settings']['color']['palette'] ) ) {
            $parent_palette = $parent_theme_json_data['settings']['color']['palette'];
        }
    }
    // Initialize child palette.
    $child_palette = array();

    // Check if the child theme has its own color palette.
    if ( isset( $theme_json_data['settings']['color']['palette'] ) && is_array( $theme_json_data['settings']['color']['palette'] ) ) {
        $child_palette = $theme_json_data['settings']['color']['palette'];
    }

    // The palette from get_data() can be keyed by origin (e.g. 'theme') rather than
    // a flat list of presets. Normalize to a flat list so every entry is a preset
    // with its own 'slug'; otherwise WordPress iterates the nested origin array as a
    // preset and emits "Undefined index: slug".
    if ( isset( $child_palette['theme'] ) && is_array( $child_palette['theme'] ) ) {
        $child_palette = $child_palette['theme'];
    }

    // Merge the parent palette with the child palette.
    $merged_palette = array_merge( $parent_palette, $child_palette );

    // Write the palette back under the 'theme' origin so it matches the structure
    // WordPress expects for merged theme.json data.
    $new_data = array(
        'version'  => 3, // Ensure the version matches the latest.
        'settings' => array(
            'color' => array(
                'palette' => array(
                    'theme' => $merged_palette,
                ),
            ),
        ),
    );

    // Update the theme JSON with the new data.
    return $theme_json->update_with( $new_data );
}
add_filter( 'wp_theme_json_data_theme', 'design_system_combine_parent_child_theme_json' );

/**
 * Enable appearance tools for super admins only.
 *
 * @param WP_Theme_JSON_Data $theme_json Theme JSON data object.
 *
 * @return WP_Theme_JSON_Data
 */
function design_system_enable_appearance_tools_for_super_admins( $theme_json ) {
    if ( ! is_super_admin() ) {
        return $theme_json;
    }

    return $theme_json->update_with(
        array(
            'version'  => 3,
            'settings' => array(
                'appearanceTools' => true,
            ),
        )
    );
}
add_filter( 'wp_theme_json_data_theme', 'design_system_enable_appearance_tools_for_super_admins', 20 );

/**
 * TEMP: Re-enable block background color in the editor.
 *
 * Remove this filter once background color testing is complete.
 *
 * @param WP_Theme_JSON_Data $theme_json Theme JSON data object.
 *
 * @return WP_Theme_JSON_Data
 */
function design_system_temp_enable_block_background_color( $theme_json ) {
    return $theme_json->update_with(
        array(
            'version'  => 3,
            'settings' => array(
                'color' => array(
                    'background' => true,
                ),
            ),
        )
    );
}
add_filter( 'wp_theme_json_data_theme', 'design_system_temp_enable_block_background_color', 25 );

/**
 * Add excerpt support to pages.
 */
add_post_type_support( 'page', 'excerpt' );
add_filter( 'get_block_type_variations', 'design_system_hero_cover_variation', 10, 2 );

/**
 * Adds a custom variation for the core/cover block.
 *
 * @see https://developer.wordpress.org/block-editor/reference-guides/block-api/block-variations
 *
 * @param array         $variations Existing block variations.
 * @param WP_Block_Type $block_type Block type being filtered.
 * @return array Modified block variations.
 */
function design_system_hero_cover_variation( $variations, $block_type ) {
    // Only modify variations for the cover block.
    if ( 'core/cover' !== $block_type->name ) {
        return $variations;
    }

    // Add a custom variation.
    $variations[] = [
        'name'        => 'hero-image',
        'title'       => __( 'Hero Image', 'design-system-wordpress-theme' ),
        'description' => __( 'For best results, use a 16:9 (HD) image, e.g. 1920x1080.', 'design-system-wordpress-theme' ),
        'isActive'    => [ 'minHeight' ],
        'scope'       => [ 'inserter' ],
        'isDefault'   => false,
        'attributes'  => [
            'metadata'     => [
                'name' => 'Hero image',
            ],
            'layout'       => [
                'type' => 'constrained',
            ],
            'templateLock' => 'contentOnly',
            'isDark'       => true,
        ],
        'icon'        => 'cover-image',
        'innerBlocks' => [
            // This group sets up a centered layout for the content and adds a name to the block for easier identification in the editor.
            [
                'core/group',
                [
                    'metadata' => [
                        'name' => 'Layout Container to center content and set width',
                    ],
                    'layout'   => [
                        'type'           => 'constrained',
                        'contentSize'    => '468px',
                        'justifyContent' => 'left',
                    ],
                ],
                [
                    // This group is used to create a 70% opaque dark blue background behind the title, description, and call-to-action button.
                    [
                        'core/group',
                        [
                            'metadata' => [
                                'name' => 'Card Container',
                            ],
                            'style'    => [
                                'color'   => [
                                    'background' => ' #013366B2', // dswp-surface-color-background-dark-blue, but with 70% opacity.
                                    'text'       => 'var:preset|color|white',
                                ],
                                'border'  => [
                                    'left'   => [
                                        'width' => '0.5rem',
                                        'color' => 'var:preset|color|accent-primary',
                                        'style' => 'solid',
                                    ],
                                    'radius' => '4px',
                                ],
                                'spacing' => [
                                    'padding' => [
                                        'top'    => '0.5rem',
                                        'right'  => '2rem',
                                        'bottom' => '1rem',
                                        'left'   => '2rem',
                                    ],
                                ],
                            ],
                        ],
                        [
                            [
                                // a Homepage Title - Required.
                                'core/heading',
                                [
                                    'metadata'    => [
                                        'name' => 'Home Page Title (Required)',
                                    ],
                                    'placeholder' => 'Home Page Title (Required)',
                                    'level'       => 1,
                                    'style'       => [
                                        'spacing' => [
                                            'padding' => [
                                                'top'    => '1.5rem',
                                                'bottom' => '1.5rem',
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                            [
                                // An optional description block.
                                'core/paragraph',
                                [
                                    'metadata'    => [
                                        'name' => 'Website Description (Optional)',
                                    ],
                                    'placeholder' => 'Description, under 160 characters.',
                                    'style'       => [
                                        'spacing'    => [
                                            'padding' => [
                                                'bottom' => '1rem',
                                            ],
                                        ],
                                        'typography' => [
                                            'fontSize'   => '1.125rem',
                                            'lineHeight' => '1.7',
                                        ],

                                    ],
                                ],
                            ],
                            [
                                'core/buttons',
                                [],
                                [
                                    [
                                        'core/button',
                                        [
                                            'className'   => 'is-style-link',
                                            'placeholder' => 'Action >',
                                            'metadata'    => [
                                                'name' => 'Call to Action Button (Optional)',
                                            ],
                                            'style'       => [
                                                'spacing' => [
                                                    'padding'  => [
                                                        'top'    => 0,
                                                        'right'  => '1.5rem',
                                                        'bottom' => '1rem',
                                                        'left'   => 0,
                                                    ],
                                                ],
                                            ],
                                        ],
                                    ],
                                ],
                            ],
                        ],
                    ],
                ],
            ],
        ],
    ];

    return $variations;
}

/**
 * Register the custom button style for this cover image variation
 *
 * @return void
 */
function design_system_register_link_button_block_style() {
    // Use the Link button style from the DSWP theme.
    register_block_style(
        'core/button',
        [
            'name'         => 'link',
            'label'        => __( 'Link', 'design-system-wordpress-theme' ),
            'inline_style' => '.wp-block-button.is-style-link > * {
                background: none;
                border: none;
                padding: 0;
                font: inherit;
                cursor: pointer;
                outline: inherit;
                text-decoration: underline;
		    }',
        ]
    );
}

add_action( 'init', 'design_system_register_link_button_block_style' );
